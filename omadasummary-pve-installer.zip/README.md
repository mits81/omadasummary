# Omada Summary Proxmox VE Installer

This installer is designed to be run on the Proxmox VE host.

It creates a Debian 12 LXC container, installs Docker inside it, downloads the app from:

https://github.com/mits81/omadasummary

and starts the project using Docker Compose.

## Run

```bash
chmod +x install-omadasummary-pve.sh
./install-omadasummary-pve.sh
```

## Optional settings

```bash
CTID=232 HOSTNAME=omadasummary MEMORY=2048 DISK_SIZE=12G BRIDGE=vmbr0 ./install-omadasummary-pve.sh
```

## After install

```bash
pct exec 231 -- nano /opt/omadasummary/.env
pct exec 231 -- bash -lc 'cd /opt/omadasummary && docker compose restart'
```
