#!/usr/bin/env bash
set -euo pipefail

# Omada Summary - Proxmox VE LXC Installer
# GitHub file source: https://github.com/mits81/omadasummary
#
# Run this script on the Proxmox VE host as root.
#
# Example:
#   bash install-omadasummary-pve.sh
#
# Optional environment overrides:
#   CTID=231 HOSTNAME=omadasummary DISK_SIZE=8G MEMORY=1024 CORES=1 BRIDGE=vmbr0 bash install-omadasummary-pve.sh

APP_NAME="omadasummary"
GITHUB_USER="mits81"
GITHUB_REPO="omadasummary"
GITHUB_BRANCH="${GITHUB_BRANCH:-main}"
GITHUB_ZIP_URL="https://github.com/${GITHUB_USER}/${GITHUB_REPO}/archive/refs/heads/${GITHUB_BRANCH}.zip"

CTID="${CTID:-231}"
HOSTNAME="${HOSTNAME:-omadasummary}"
TEMPLATE_STORAGE="${TEMPLATE_STORAGE:-local}"
ROOTFS_STORAGE="${ROOTFS_STORAGE:-local-lvm}"
DISK_SIZE="${DISK_SIZE:-8G}"
MEMORY="${MEMORY:-1024}"
SWAP="${SWAP:-512}"
CORES="${CORES:-1}"
BRIDGE="${BRIDGE:-vmbr0}"
IPCONFIG="${IPCONFIG:-ip=dhcp}"
PASSWORD="${PASSWORD:-$(openssl rand -base64 18 | tr -dc 'A-Za-z0-9' | head -c 16)}"
TEMPLATE="${TEMPLATE:-debian-12-standard_12.7-1_amd64.tar.zst}"
TEMPLATE_PATH="/var/lib/vz/template/cache/${TEMPLATE}"

echo "============================================================"
echo " Omada Summary Proxmox VE Installer"
echo "============================================================"
echo "Container ID:   ${CTID}"
echo "Hostname:       ${HOSTNAME}"
echo "GitHub source:  ${GITHUB_USER}/${GITHUB_REPO} (${GITHUB_BRANCH})"
echo "Bridge:         ${BRIDGE}"
echo "IP config:      ${IPCONFIG}"
echo "============================================================"

if [[ $EUID -ne 0 ]]; then
  echo "ERROR: Please run this script as root on the Proxmox VE host."
  exit 1
fi

if ! command -v pct >/dev/null 2>&1; then
  echo "ERROR: pct command not found. This must be run on a Proxmox VE host."
  exit 1
fi

if pct status "${CTID}" >/dev/null 2>&1; then
  echo "ERROR: Container ${CTID} already exists. Choose another CTID, for example:"
  echo "       CTID=232 bash install-omadasummary-pve.sh"
  exit 1
fi

echo "[1/8] Installing required host packages..."
apt-get update
apt-get install -y curl unzip ca-certificates jq

echo "[2/8] Checking Debian 12 LXC template..."
if [[ ! -f "${TEMPLATE_PATH}" ]]; then
  echo "Template not found locally. Downloading ${TEMPLATE}..."
  pveam update
  pveam download "${TEMPLATE_STORAGE}" "${TEMPLATE}"
fi

echo "[3/8] Creating LXC container..."
pct create "${CTID}" "${TEMPLATE_STORAGE}:vztmpl/${TEMPLATE}" \
  --hostname "${HOSTNAME}" \
  --rootfs "${ROOTFS_STORAGE}:${DISK_SIZE}" \
  --memory "${MEMORY}" \
  --swap "${SWAP}" \
  --cores "${CORES}" \
  --net0 "name=eth0,bridge=${BRIDGE},${IPCONFIG}" \
  --ostype debian \
  --unprivileged 1 \
  --features nesting=1,keyctl=1 \
  --password "${PASSWORD}" \
  --onboot 1 \
  --start 1

echo "[4/8] Waiting for container network..."
sleep 8

echo "[5/8] Installing Docker and tools inside container..."
pct exec "${CTID}" -- bash -lc '
set -e
apt-get update
apt-get install -y ca-certificates curl gnupg unzip git nano
install -m 0755 -d /etc/apt/keyrings
if [ ! -f /etc/apt/keyrings/docker.gpg ]; then
  curl -fsSL https://download.docker.com/linux/debian/gpg | gpg --dearmor -o /etc/apt/keyrings/docker.gpg
  chmod a+r /etc/apt/keyrings/docker.gpg
fi
echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/debian bookworm stable" > /etc/apt/sources.list.d/docker.list
apt-get update
apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
systemctl enable --now docker
'

echo "[6/8] Downloading ${GITHUB_USER}/${GITHUB_REPO} from GitHub..."
pct exec "${CTID}" -- bash -lc "
set -e
rm -rf /opt/${APP_NAME} /tmp/${APP_NAME}.zip /tmp/${GITHUB_REPO}-${GITHUB_BRANCH}
curl -L '${GITHUB_ZIP_URL}' -o /tmp/${APP_NAME}.zip
unzip -q /tmp/${APP_NAME}.zip -d /tmp
mv /tmp/${GITHUB_REPO}-${GITHUB_BRANCH} /opt/${APP_NAME}
"

echo "[7/8] Preparing environment file..."
pct exec "${CTID}" -- bash -lc "
set -e
cd /opt/${APP_NAME}
if [ ! -f .env ]; then
  if [ -f .env.example ]; then
    cp .env.example .env
  else
    cat > .env <<'ENVEOF'
# Omada Controller settings
OMADA_URL=https://192.168.0.1:8043
OMADA_SITE=Default
OMADA_USERNAME=admin
OMADA_PASSWORD=changeme

# Web dashboard
PORT=3000
POLL_INTERVAL_SECONDS=30

# Optional: comma-separated device names, MAC addresses or IPs that are critical for event operation
CRITICAL_DEVICES=
ENVEOF
  fi
fi
"

echo "[8/8] Starting Omada Summary..."
pct exec "${CTID}" -- bash -lc "
set -e
cd /opt/${APP_NAME}

if [ -f docker-compose.yml ]; then
  docker compose up -d --build
elif [ -f compose.yml ]; then
  docker compose -f compose.yml up -d --build
else
  echo 'ERROR: No docker-compose.yml or compose.yml found in GitHub repo.'
  echo 'Your repo must contain a Docker Compose project.'
  exit 1
fi
"

IP_ADDR="$(pct exec "${CTID}" -- bash -lc "hostname -I | awk '{print \$1}'" | tr -d '\r' || true)"

echo
echo "============================================================"
echo " Installation complete"
echo "============================================================"
echo "Container ID: ${CTID}"
echo "Hostname:     ${HOSTNAME}"
echo "Root password generated for LXC: ${PASSWORD}"
echo
if [[ -n "${IP_ADDR}" ]]; then
  echo "Dashboard should be available at:"
  echo "  http://${IP_ADDR}:3000"
else
  echo "Could not detect container IP. Check with:"
  echo "  pct exec ${CTID} -- hostname -I"
fi
echo
echo "Next steps:"
echo "  1. Edit Omada settings:"
echo "     pct exec ${CTID} -- nano /opt/${APP_NAME}/.env"
echo
echo "  2. Restart the app:"
echo "     pct exec ${CTID} -- bash -lc 'cd /opt/${APP_NAME} && docker compose restart'"
echo
echo "  3. View logs:"
echo "     pct exec ${CTID} -- bash -lc 'cd /opt/${APP_NAME} && docker compose logs -f'"
echo "============================================================"
